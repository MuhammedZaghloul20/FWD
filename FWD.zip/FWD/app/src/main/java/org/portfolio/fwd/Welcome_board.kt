package org.portfolio.fwd

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.welcome_board.*
import kotlinx.android.synthetic.main.welcome_board.view.*


class welcome_board : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view= inflater.inflate(R.layout.welcome_board, container, false)


        view.one.animate().translationXBy(-700f).duration=500
        Handler().postDelayed({
            text1.animate().alpha(1f).duration=500
        },1000)
        Handler().postDelayed({
            view.one.visibility=View.GONE
            view.two.visibility=View.VISIBLE
            view.two.animate().translationXBy(-700f).duration=500
            Handler().postDelayed({
                text2.animate().alpha(1f).duration=500
            },1000)
            Handler().postDelayed({
                continu.animate().alpha(1f).duration=500
                continu.setOnClickListener{
                    val intent =Intent(activity, List_1::class.java)
                    startActivity(intent)
                }
            },2000)
        },4500)




        return view
    }


}