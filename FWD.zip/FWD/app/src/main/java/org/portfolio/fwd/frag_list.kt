package org.portfolio.fwd

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.products.*


class frag_list : Fragment() {


    lateinit var list: ArrayList<shoes>
    lateinit var adapter: MyAdapter
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view= inflater.inflate(R.layout.products, container, false)




        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        list = arrayListOf(shoes("Nike","200",R.drawable.shoe))
        list.add(shoes("Puma","350",R.drawable.shoe2))
        list.add(shoes("Nike","200",R.drawable.shoe))
        list.add(shoes("Puma","350",R.drawable.shoe2))
        list.add(shoes("Nike","200",R.drawable.shoe))
        list.add(shoes("Puma","350",R.drawable.shoe2))
        list.add(shoes("Nike","200",R.drawable.shoe))

        list.add(shoes("Puma","350",R.drawable.shoe2))

        adapter = MyAdapter(list)

        rlist.adapter= adapter
        rlist.layoutManager= LinearLayoutManager(view.context)
    }

}