package org.portfolio.fwd

data class shoes(var brand:String,var price :String,var image :Int)
